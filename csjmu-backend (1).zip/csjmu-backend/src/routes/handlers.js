/**
 * Framework-free request handlers. Each takes ({ params, query }) and returns
 * { status, body }. app.js adapts them to Express, which keeps the logic easy to test.
 */
const ok = body => ({ status: 200, body });
const notFound = what => ({ status: 404, body: { error: 'not_found', message: what + ' not found' } });
const bad = message => ({ status: 400, body: { error: 'bad_request', message } });

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const STATUSES = ['upcoming', 'ongoing', 'past', 'active'];

function createHandlers({ catalog, events, search }) {
  const list = items => ok({ count: items.length, items });

  return {
    health: () => ok({ status: 'ok', time: new Date().toISOString() }),

    departments: ({ query }) => list(catalog.listDepartments(query)),
    department: ({ params }) => {
      const d = catalog.getDepartment(params.id);
      return d ? ok(d) : notFound('Department');
    },

    faqs: ({ query }) => list(catalog.listFaqs(query)),
    documents: ({ query }) => list(catalog.listDocuments(query)),

    offices: ({ query }) => list(catalog.listOffices(query)),
    office: ({ params }) => {
      const o = catalog.getOffice(params.id);
      return o ? ok(o) : notFound('Office');
    },

    buildings: () => list(catalog.listBuildings()),
    building: ({ params }) => {
      const b = catalog.getBuilding(params.id);
      return b ? ok(b) : notFound('Building');
    },

    eventCategories: () => list(events.categories()),
    events: ({ query }) => {
      const { category, status, from, to } = query;
      if (status && !STATUSES.includes(status)) return bad('status must be one of ' + STATUSES.join(', '));
      if (category && !events.categories().some(c => c.id === category)) return bad('unknown category');
      for (const [k, v] of Object.entries({ from, to })) {
        if (v && !DATE_RE.test(v)) return bad(k + ' must be YYYY-MM-DD');
      }
      return list(events.list(query));
    },
    event: ({ params }) => {
      const e = events.get(params.id);
      return e ? ok(e) : notFound('Event');
    },

    search: ({ query }) => {
      if (!query.q || !query.q.trim()) return bad('q is required');
      return list(search(query.q));
    }
  };
}

module.exports = { createHandlers };
