const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'data');
const load = name => JSON.parse(fs.readFileSync(path.join(dir, name + '.json'), 'utf8'));

module.exports = {
  departments: load('departments'),
  faqs: load('faqs'),
  documents: load('documents'),
  buildings: load('buildings'),
  units: load('units'),
  offices: load('offices'),
  events: load('events'),
  eventCategories: load('event-categories')
};
