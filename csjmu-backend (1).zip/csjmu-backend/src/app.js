const express = require('express');
const cors = require('cors');
const defaultData = require('./data');
const { createCatalog } = require('./services/catalog');
const { createEvents } = require('./services/events');
const { createSearch } = require('./services/search');
const { createHandlers } = require('./routes/handlers');

function createApp({ data = defaultData, corsOrigins = process.env.CORS_ORIGINS || '*' } = {}) {
  const catalog = createCatalog(data);
  const events = createEvents(data);
  const search = createSearch(data, events);
  const h = createHandlers({ catalog, events, search });

  const app = express();
  app.disable('x-powered-by');
  app.use(cors({ origin: corsOrigins === '*' ? '*' : corsOrigins.split(',').map(s => s.trim()) }));

  // Adapt a framework-free handler to Express. Public, read-only data: cache briefly.
  const wrap = fn => (req, res) => {
    const { status, body } = fn({ params: req.params, query: req.query });
    if (status === 200 && req.path !== '/api/health') res.set('Cache-Control', 'public, max-age=300');
    res.status(status).json(body);
  };

  app.get('/api/health', wrap(h.health));
  app.get('/api/departments', wrap(h.departments));
  app.get('/api/departments/:id', wrap(h.department));
  app.get('/api/faqs', wrap(h.faqs));
  app.get('/api/documents', wrap(h.documents));
  app.get('/api/offices', wrap(h.offices));
  app.get('/api/offices/:id', wrap(h.office));
  app.get('/api/campus/buildings', wrap(h.buildings));
  app.get('/api/campus/buildings/:id', wrap(h.building));
  app.get('/api/events/categories', wrap(h.eventCategories));
  app.get('/api/events', wrap(h.events));
  app.get('/api/events/:id', wrap(h.event));
  app.get('/api/search', wrap(h.search));

  app.use((req, res) => res.status(404).json({ error: 'not_found', message: 'No such route' }));
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    console.error(err);
    res.status(500).json({ error: 'server_error', message: 'Something went wrong' });
  });
  return app;
}

module.exports = { createApp };
