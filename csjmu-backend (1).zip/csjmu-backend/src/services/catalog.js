const { matches } = require('./text');

/** Read-only queries over departments, FAQs, documents, offices and the campus map. */
function createCatalog(data) {
  const byId = (list, id) => list.find(x => x.id === id) || null;

  const buildingWithUnits = b => ({
    ...b,
    units: data.units.filter(u => u.building === b.id),
    offices: data.offices.filter(o => o.buildingId === b.id)
  });

  return {
    listDepartments: ({ q } = {}) =>
      data.departments
        .filter(d => matches(q, d.name, d.summary))
        .map(({ id, name, summary, location, hours }) => ({ id, name, summary, location, hours })),

    getDepartment(id) {
      const dept = byId(data.departments, id);
      if (!dept) return null;
      return {
        ...dept,
        faqs: data.faqs.filter(f => f.department === id),
        downloads: data.documents.filter(d => d.department === id)
      };
    },

    listFaqs: ({ department, q } = {}) =>
      data.faqs.filter(f => (!department || f.department === department) && matches(q, f.question, f.answer)),

    listDocuments: ({ department } = {}) =>
      data.documents.filter(d => !department || d.department === department),

    listOffices: ({ q, building } = {}) =>
      data.offices.filter(o => (!building || o.buildingId === building) && matches(q, o.name, o.location, o.email)),

    getOffice: id => byId(data.offices, id),

    listBuildings: () => data.buildings.map(b => ({ ...b, unitCount: data.units.filter(u => u.building === b.id).length })),

    getBuilding(id) {
      const b = byId(data.buildings, id);
      return b ? buildingWithUnits(b) : null;
    }
  };
}

module.exports = { createCatalog };
