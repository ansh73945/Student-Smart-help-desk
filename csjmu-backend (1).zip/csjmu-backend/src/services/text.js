/** Case-insensitive "does any field contain every word of the query". */
function matches(q, ...fields) {
  const words = String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
  if (!words.length) return true;
  const hay = fields.filter(Boolean).join(' ').toLowerCase();
  return words.every(w => hay.includes(w));
}
module.exports = { matches };
