const { matches } = require('./text');

/** Cross-collection search used by the help desk's global search box. */
function createSearch(data, events) {
  return function search(q, { limit = 20 } = {}) {
    if (!q || !q.trim()) return [];
    const hits = [];
    data.departments.forEach(d => matches(q, d.name, d.summary) &&
      hits.push({ type: 'department', id: d.id, title: d.name, snippet: d.summary }));
    data.faqs.forEach(f => matches(q, f.question, f.answer) &&
      hits.push({ type: 'faq', id: f.id, title: f.question, snippet: f.answer.slice(0, 100), department: f.department }));
    data.offices.forEach(o => matches(q, o.name, o.location) &&
      hits.push({ type: 'office', id: o.id, title: o.name, snippet: o.location }));
    data.buildings.forEach(b => matches(q, b.name, b.shortName) &&
      hits.push({ type: 'building', id: b.id, title: b.name, snippet: null }));
    events.list({ q }).forEach(e =>
      hits.push({ type: 'event', id: e.id, title: e.title, snippet: e.startDate }));
    return hits.slice(0, limit);
  };
}

module.exports = { createSearch };
