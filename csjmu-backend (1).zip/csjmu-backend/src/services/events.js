const { matches } = require('./text');

const DAY = 864e5;
const isoDay = d => d.toISOString().slice(0, 10);
const toUtc = iso => Date.parse(iso + 'T00:00:00Z');

/** Status of an event relative to `today` (YYYY-MM-DD). Mirrors the logic used by the front-end calendar. */
function statusOf(ev, today) {
  const t = toUtc(today), start = toUtc(ev.startDate), end = toUtc(ev.endDate || ev.startDate);
  if (end < t) return { status: 'past', label: 'Ended', daysUntilStart: null };
  if (start <= t) {
    return { status: 'ongoing', label: ev.endDate && end > t ? 'Ongoing' : 'Today', daysUntilStart: 0 };
  }
  return { status: 'upcoming', label: 'Upcoming', daysUntilStart: Math.round((start - t) / DAY) };
}

function createEvents(data, { now = () => new Date() } = {}) {
  const decorate = (ev, today) => ({
    ...ev,
    categoryLabel: data.eventCategories[ev.category] || ev.category,
    ...statusOf(ev, today)
  });

  return {
    categories: () => Object.entries(data.eventCategories).map(([id, label]) => ({ id, label })),

    /**
     * status: upcoming | ongoing | past | active (= ongoing + upcoming)
     * from/to: YYYY-MM-DD, keeps events whose date range overlaps the window
     */
    list({ category, status, q, from, to, today } = {}) {
      const day = today || isoDay(now());
      let out = data.events.map(e => decorate(e, day));
      if (category) out = out.filter(e => e.category === category);
      if (status === 'active') out = out.filter(e => e.status !== 'past');
      else if (status) out = out.filter(e => e.status === status);
      if (from) out = out.filter(e => (e.endDate || e.startDate) >= from);
      if (to) out = out.filter(e => e.startDate <= to);
      if (q) out = out.filter(e => matches(q, e.title, e.notes, e.venue, e.organiser));
      const past = status === 'past';
      return out.sort((a, b) => (past ? b.startDate.localeCompare(a.startDate) : a.startDate.localeCompare(b.startDate)));
    },

    get(id, today) {
      const ev = data.events.find(e => e.id === id);
      return ev ? decorate(ev, today || isoDay(now())) : null;
    }
  };
}

module.exports = { createEvents, statusOf };
