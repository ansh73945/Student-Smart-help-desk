#!/usr/bin/env node
/**
 * Extracts the public university data embedded in the help-desk front-end
 * (source/csjmu-help-desk-fixed.html) into JSON files under data/.
 *
 * Usage:  node scripts/extract-data.js [path/to/help-desk.html]
 *
 * Re-run this whenever the HTML changes, or edit the JSON in data/ directly
 * once the backend becomes the source of truth.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const src = path.resolve(process.argv[2] || path.join(__dirname, '..', 'source', 'csjmu-help-desk-fixed.html'));
const outDir = path.join(__dirname, '..', 'data');
const html = fs.readFileSync(src, 'utf8');

/** Pull `const NAME = <literal>;` out of the page and evaluate only that literal. */
function grab(name, prelude = '') {
  const m = new RegExp('const\\s+' + name + '\\s*=\\s*([\\[{])').exec(html);
  if (!m) throw new Error('Could not find const ' + name);
  const first = m[1];
  const close = first === '[' ? ']' : '}';
  const begin = m.index + m[0].length - 1;
  let depth = 0, inStr = null, esc = false, i = begin;
  for (; i < html.length; i++) {
    const c = html[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === inStr) inStr = null;
      continue;
    }
    if (c === '"' || c === "'" || c === '`') { inStr = c; continue; }
    if (c === first) depth++;
    else if (c === close && --depth === 0) { i++; break; }
  }
  return vm.runInNewContext(prelude + '(' + html.slice(begin, i) + ')', {}, { timeout: 1000 });
}

const iconPrelude = 'var icons = new Proxy({}, {get: function(){return null}});';
const slug = s => s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

// ---- departments -----------------------------------------------------------
const departments = grab('departments', iconPrelude).map(({ icon, ...d }) => d);

// ---- FAQs ------------------------------------------------------------------
const faqs = grab('faqs').map((f, i) => ({
  id: 'faq-' + String(i + 1).padStart(2, '0'),
  department: f.dept, question: f.q, answer: f.a
}));

// ---- documents / downloads -------------------------------------------------
// The page labels documents with display names; map them to department ids.
const docDeptAlias = { 'Exams': 'exams', 'ID Cards': 'idcard', 'Academic Records': 'records' };
const deptIds = new Set(departments.map(d => d.id));
const documents = grab('pdfDocs').map(d => {
  const guess = docDeptAlias[d.dept] || d.dept.toLowerCase();
  return { id: slug(d.name), name: d.name, department: deptIds.has(guess) ? guess : null, departmentLabel: d.dept };
});

// ---- campus map: buildings + units inside them -----------------------------
const buildings = grab('B').map(b => ({
  id: b.id, name: b.n, shortName: b.s,
  mapShape: { x: b.x, y: b.y, w: b.w, h: b.h }, door: { x: b.d[0], y: b.d[1] }, roadY: b.r
}));
// Units are either a named office (field m) or a facility with a title (t) and a note (h).
const units = grab('U').map(u => ({
  building: u.b, name: u.m || u.t, floor: u.f, room: u.r || null, note: u.h || null, isOffice: Boolean(u.m)
}));

// ---- offices ---------------------------------------------------------------
const offices = grab('offices').map(o => {
  const unit = units.find(u => u.isOffice && o.name.toLowerCase().startsWith(u.name.toLowerCase()));
  return {
    id: slug(o.name).slice(0, 60),
    name: o.name,
    location: o.building,
    buildingId: unit ? unit.building : null,
    hours: o.hours, phone: o.phone || null, email: o.email || null
  };
});

// ---- events (seeded in the page from public pages) -------------------------
const eventPrelude = "var HP='https://csjmu.ac.in/',CD='https://collegedunia.com/university/25931-chhatrapati-shahu-ji-maharaj-university-csjmu-kanpur';";
const events = grab('SEED', eventPrelude).map(e => ({
  id: e.id, title: e.t, category: e.c, startDate: e.d, endDate: e.e || null,
  time: e.tm || null, venue: e.v || null, organiser: e.o || null, notes: e.n || null, source: e.src || null
}));

const eventCategories = grab('C');

const write = (n, v) => fs.writeFileSync(path.join(outDir, n + '.json'), JSON.stringify(v, null, 2) + '\n');
fs.mkdirSync(outDir, { recursive: true });
write('departments', departments);
write('faqs', faqs);
write('documents', documents);
write('buildings', buildings);
write('units', units);
write('offices', offices);
write('events', events);
write('event-categories', eventCategories);

console.log(`departments:${departments.length} faqs:${faqs.length} documents:${documents.length} ` +
  `buildings:${buildings.length} units:${units.length} offices:${offices.length} events:${events.length}`);
