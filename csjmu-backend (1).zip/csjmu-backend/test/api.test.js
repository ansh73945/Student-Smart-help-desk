const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../src/data');
const { createCatalog } = require('../src/services/catalog');
const { createEvents, statusOf } = require('../src/services/events');
const { createSearch } = require('../src/services/search');
const { createHandlers } = require('../src/routes/handlers');

const catalog = createCatalog(data);
const events = createEvents(data, { now: () => new Date('2026-10-10T08:00:00Z') });
const h = createHandlers({ catalog, events, search: createSearch(data, events) });
const call = (name, query = {}, params = {}) => h[name]({ query, params });

test('data integrity: every FAQ, document and office points at something real', () => {
  const deptIds = new Set(data.departments.map(d => d.id));
  const buildingIds = new Set(data.buildings.map(b => b.id));
  data.faqs.forEach(f => assert.ok(deptIds.has(f.department), 'faq dept ' + f.department));
  data.documents.forEach(d => assert.ok(deptIds.has(d.department), 'doc dept ' + d.name));
  data.units.forEach(u => assert.ok(buildingIds.has(u.building), 'unit building ' + u.building));
  data.offices.filter(o => o.buildingId).forEach(o => assert.ok(buildingIds.has(o.buildingId)));
  assert.equal(new Set(data.offices.map(o => o.id)).size, data.offices.length, 'office ids unique');
});

test('departments list and detail', () => {
  const list = call('departments').body;
  assert.equal(list.count, data.departments.length);
  const d = call('department', {}, { id: 'exams' }).body;
  assert.equal(d.id, 'exams');
  assert.ok(d.faqs.length >= 2 && d.faqs.every(f => f.department === 'exams'));
  assert.ok(d.downloads.length >= 1);
  assert.equal(call('department', {}, { id: 'nope' }).status, 404);
});

test('faqs filter by department and text', () => {
  assert.ok(call('faqs', { department: 'hostel' }).body.items.every(f => f.department === 'hostel'));
  const r = call('faqs', { q: 'refund' }).body;
  assert.equal(r.count, 1);
  assert.equal(r.items[0].department, 'fees');
});

test('offices and campus map are linked', () => {
  const adm = call('offices', { q: 'admissions' }).body.items;
  assert.equal(adm[0].buildingId, 'admin');
  const b = call('building', {}, { id: 'admin' }).body;
  assert.ok(b.offices.some(o => o.id === 'admissions-cell'));
  assert.ok(b.units.some(u => u.room === 'Room 4'));
  assert.equal(call('buildings').body.count, 14);
  assert.equal(call('building', {}, { id: 'zzz' }).status, 404);
});

test('event status is computed relative to today', () => {
  const ev = { startDate: '2026-10-03', endDate: '2026-10-17' };
  assert.equal(statusOf(ev, '2026-10-10').status, 'ongoing');
  assert.equal(statusOf(ev, '2026-10-18').status, 'past');
  assert.deepEqual(
    [statusOf(ev, '2026-10-01').status, statusOf(ev, '2026-10-01').daysUntilStart], ['upcoming', 2]);
  assert.equal(statusOf({ startDate: '2026-10-10' }, '2026-10-10').label, 'Today');
});

test('events filters (clock pinned to 2026-10-10)', () => {
  const upcoming = call('events', { status: 'upcoming' }).body.items;
  assert.ok(upcoming.every(e => e.status === 'upcoming'));
  const sorted = [...upcoming].sort((a, b) => a.startDate.localeCompare(b.startDate));
  assert.deepEqual(upcoming.map(e => e.id), sorted.map(e => e.id));
  const past = call('events', { status: 'past' }).body.items;
  assert.ok(past.length && past[0].startDate >= past[past.length - 1].startDate, 'past is newest first');
  assert.ok(call('events', { category: 'admission' }).body.items.every(e => e.category === 'admission'));
  const window = call('events', { from: '2026-10-14', to: '2026-10-16' }).body.items.map(e => e.id);
  assert.ok(window.includes('s4') && window.includes('s2') && !window.includes('s8'));
});

test('events validation and lookup', () => {
  assert.equal(call('events', { status: 'soon' }).status, 400);
  assert.equal(call('events', { category: 'bogus' }).status, 400);
  assert.equal(call('events', { from: '10/10/2026' }).status, 400);
  assert.equal(call('event', {}, { id: 's2' }).body.categoryLabel, 'Academic');
  assert.equal(call('event', {}, { id: 'x' }).status, 404);
});

test('search spans collections and requires q', () => {
  assert.equal(call('search').status, 400);
  const types = new Set(call('search', { q: 'library' }).body.items.map(i => i.type));
  assert.ok(types.has('building'));
  assert.ok(call('search', { q: 'admit card' }).body.items.some(i => i.type === 'faq'));
});
