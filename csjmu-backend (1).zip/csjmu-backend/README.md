# CSJMU Help Desk – Public Data API

Node.js + Express backend that serves the public university data used by the
CSJMU Smart Student Help Desk: departments, FAQs, downloads, office directory,
events calendar and campus map. It is read-only; no database or login needed.

## Run

```bash
npm install
cp .env.example .env     # optional
npm start                # http://localhost:3000
npm test                 # 8 tests, uses Node's built-in runner
```

## Endpoints

| Method | Path | Query |
|---|---|---|
| GET | `/api/health` | |
| GET | `/api/departments` | `q` |
| GET | `/api/departments/:id` | returns steps, documents, FAQs and downloads |
| GET | `/api/faqs` | `department`, `q` |
| GET | `/api/documents` | `department` |
| GET | `/api/offices` | `q`, `building` |
| GET | `/api/offices/:id` | |
| GET | `/api/campus/buildings` | |
| GET | `/api/campus/buildings/:id` | includes its units and offices |
| GET | `/api/events/categories` | |
| GET | `/api/events` | `category`, `status` (upcoming, ongoing, past, active), `from`, `to` (YYYY-MM-DD), `q` |
| GET | `/api/events/:id` | |
| GET | `/api/search` | `q` (required) |

Event `status` is calculated on the server from today's date.

## Where the data comes from

`data/*.json` is generated from the front-end file in `source/` by
`npm run extract`. That file is where the departments, FAQs, offices, map and
the seeded events were originally written. **Nothing is fetched live from
csjmu.ac.in**, so check phone numbers, emails, room numbers and event dates
against the official site before launch. Once you start editing the JSON
directly, stop running `npm run extract` or it will overwrite your edits.

## Layout

```
src/app.js              Express wiring (thin)
src/routes/handlers.js  request logic, framework-free
src/services/           catalog, events, search
data/                   JSON data
scripts/extract-data.js builds data/ from the HTML
test/                   node:test suite
```

## Not included yet

Maintenance tickets, appointment requests and staff login still live in the
browser (`localStorage`, demo PIN `1234`). They need a database and real
authentication, so they are the natural next backend part.
